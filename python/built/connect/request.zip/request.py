import requests
import base64
import struct
import sys

hostName, serverPort = sys.argv[1], int(sys.argv[2])
url = f"http://{hostName}:{serverPort}"
img = base64.b64encode(open("data.HEIC", "rb").read())
response = requests.get(url, data=img)
print(struct.unpack('>f', response.content)[0])
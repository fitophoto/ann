# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['microservicev2']

package_data = \
{'': ['*'], 'microservicev2': ['models/*']}

install_requires = \
['Pillow>=9.1.1,<10.0.0',
 'PyYAML>=6.0,<7.0',
 'matplotlib>=3.5.2,<4.0.0',
 'numpy>=1.22.4,<2.0.0',
 'opencv-python>=4.6.0,<5.0.0',
 'pandas>=1.4.2,<2.0.0',
 'pillow-heif>=0.2.5,<0.3.0',
 'seaborn>=0.11.2,<0.12.0',
 'sklearn>=0.0,<0.1',
 'torch>=1.11.0,<2.0.0',
 'torchvision>=0.12.0,<0.13.0',
 'tqdm>=4.64.0,<5.0.0']

setup_kwargs = {
    'name': 'microservicev2',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)

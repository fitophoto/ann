from launchServer import launchServer

if __name__ == "__main__":
    launchServer("192.168.88.254", 8888, "C:/Users/Wxei/Desktop/microServiceV2/microServiceV2/microservicev2/models")